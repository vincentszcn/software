This is release of DTCping 1.7

Note: 
1. You need to replace A and B with proper Network name of your testing machihnes.
2. You should input name as is without //
      Even though DTCping will work if you give IP address, 
       however the test with IP address is not considered valid for DTC communication.
3. There will be two files for test on each direction.
4. To use this tool, you need to have read/browse right to registry key: HKEY_CLASSES_ROOT

I. Prepare: copy this exe to both  A and B
   If there is any error, copy the c:\dtcping.log on both A and B
   before further testing.

II. Test B ---> A:
  On Box A, Start dtcping.exe
      Press Start Server Button
  On Box B, Start dtcping.exe
      Type A in the remote host name.
      Press Ping Button
  Close dtcping.exe on both A and B
Note:
  Screen display is a subset of information of dtcping.log, which should be located in
  the same directory as dtcping.exe. Even though DTCping won't overwrite the log files,
  it is recommended that you rename/copy the log on both A and B before further testing.

III. Test A ---> B:
  On Box B, Start dtcping.exe
      Press Start Server Button
  On Box A, Start dtcping.exe
      Type B in the remote host name.
      Press Ping Button
  Close dtcping.exe on both A and B


What this tool is going to do?
1. Name Resolution
   Each DTC service uses it's peers' name to talk to each other. 
   Hence, name resolution is the first step toward DTC trouble shooting.
   This Tool first tries to resolve computer network name to IP address.
   With this IP address, this tool get the host name by IP address.
   Version 1.7 added routing functionality.
2. RPC communication
   RPC is the basis for DTC communication. 
   This tool tests RPC communication using dynamic port with TCP/IP protocol
   A successful two way RPC communication is required for DTC to function.
3. DTC communication
   DTC is based on 2-way RPC and uses CM protocol to establish connections.
   This tool will simulate MSDTC at low level (connection manager level).
   It will also touch all registry entries MSDTC will touch during MSDTC start up.
4. Current Adapter configuration will be logged (this function is not implemented for NT4 platform).
5. If cluster environment is detected, the IP address for MSDTC resource will be logged.
