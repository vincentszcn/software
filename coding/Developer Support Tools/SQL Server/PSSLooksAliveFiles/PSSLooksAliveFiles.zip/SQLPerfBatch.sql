print 'Start Time:' Select getdate()

DBCC SQLPerf(UMSSTATS)
DBCC SQLPerf(WAITSTATS)

if @@error<>0
begin
	RAISERROR("SQLPerf Batch Error", 11, 1)
	print 'Error Time:' Select getdate()
	return
end

print 'End Time:' Select getdate()

EXIT (select 80000)
