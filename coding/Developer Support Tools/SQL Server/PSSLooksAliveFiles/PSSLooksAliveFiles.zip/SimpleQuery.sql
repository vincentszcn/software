print 'Start Time: ' select getdate()

select @@servername

if @@error<>0
begin
	RAISERROR("SimpleQuery Batch Error", 11, 1)
	return
end

print 'End Time: ' select getdate()
EXIT (select 90000)
