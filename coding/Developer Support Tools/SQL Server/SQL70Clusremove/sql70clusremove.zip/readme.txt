                 Readme.txt for uninstalling SQL Server 7.0 Clustering

The appropriate way to remove SQL Server 7.0 Clustering is by running the same cluster wizard that was used to cluster it.  The following document explains how to uncluster SQL Server 7.0 if an error prevents the cluster wizard from functioning properly.

You will need your SQL Server 7.0 Enterprise Edition CD available or a copy of it on the local hard drive of each node.

Note: "Show all files" must be enabled on both nodes.  If it is not enabled on both nodes, the files that are hidden are not "unvirtualized" when you run the sqlclusremove.bat.

Step 1
------

Take offline any SQL Services running from Cluster Administrator:

- SQL Server IP Address
- SQL Server Network Name
- SQL Server Virtual Generic Service
- SQL Server 7.0
- SQL Server Agent 7.0
- MSDTC IP Address
- MSDTC Network Name
- MSDTC Service

Note: If just using sockets leave the SQL Server IP Address and Network Name so you can make the local connection required to do the SP_DROPSERVER and SP_ADDSERVER.

Step 2
------

Stop all unnecessary services on both nodes per Q219264	INF: Installation Order, Cluster Server Support for SQL 7.0 (covers both NT4 & Windows 2000) http://support.microsoft.com/support/kb/articles/q219/2/64.asp
.
Stop all applications running on both nodes.

Step 3
------

Delete the resources listed in Step 1 through Cluster Administrator.

Step 4
------

Create a directory on each Node (ie. c:\removesqlcluster).
Copy the unzipped files included with this document into that directory on each Node.
_____________________________________________________________________________________

If ACTIVE / PASSIVE

- Edit the SQLclusRemove.bat on NODE1.
- Do a Search\ReplaceAll on the following:
  
	Find: NCVSSQL2
	Replace: Your Virtual SQL Server Name

	Find: e:\mssql7\binn
	Replace: Your MSSQL7\binn directory

- Save the batch file.
- REPEAT these steps on NODE2 with the same Virtual SQL Server Name and drive specification.
- Execute SQLclusRemove.bat on both nodes.

Note: If you have completely lost a node and had to rebuild it, only execute this on the good node.

- Reboot both nodes.
_______________________________________________________________________________________

If ACTIVE / ACTIVE

- Edit the SQLclusRemove.bat on Node1.
- Do a Search\ReplaceAll on the following:
  
	Find: NCVSSQL2
	Replace: Your First Active Virtual SQL Server Name

	Find: e:\mssql7\binn
	Replace: Your MSSQL7\binn directory

- Save the batch file.
- Then edit SQLclusRemove2.bat on node1 the same way by replacing NCVSSQL2 with your Second   Active Virtual SQL Server Name and the second file MSSQL7\binn directory.

- Execute both batch files: SQLclusRemove.bat and SQLclusRemove2.bat on Node1, then execute these batches on Node2.

Note: If you have completely lost a node and had to rebuild it, only execute this on the good node.

- Reboot both nodes.
_________________________________________________________________________________________

Step 5
------

- Make sure the proper nodes own the proper groups with the proper Disk Resources, at this point the Primary must node SQL was installed from must control the cluster disk SQL was installed to.

- If you try to start SQL Server, you will get a message that setup has been tampered     with...RERUN SETUP.

- On each node that has SQL Server installed, put in the SQL 7.0 CD and run from the command   prompt:

	CDDrive:\%processor_architecture%\setup\setupsql
	(ie. F:\x86\setup\setupsql)

- You will then be prompted for a Local Install; then prompted to Upgrade - Click YES, then click   FINISH

******************************************************************************************
**** You are now back to the point where SQL Server was never clustered (virtualized).****
******************************************************************************************

If you lost an entire node, you must:

- Make sure that rebuilt node owns the disk resource.
- Delete only the binn folder.
- Rename the data folder to dataold.
- Run setup to reinstall.
- Delete the new data folder.
- Rename the dataold folder to data.

Note: You will need to run -

sp_dropserver 'virtual_server _name' 
and then run - 
sp_addserver 'local_node_name', LOCAL

to get the appropriate node name back.

Note: Lost Node - Manually uninstall and reinstall MSDTC per SQL Server Whitepaper
