Introduction:
This tool is a minimum-resource manager, which bears the backbone of a database server, but does not have the complexity involved in database server. Hence, this tool can be used in isolating MSDTC issue from OLEDB, ODBC or SQL server transaction related issues. Put it in a simple way, if this tool runs OK, MSDTC is not the issue, otherwise, it is.


Usage:
0. Copy all the files in this package to your local directory
   (Recommend one copy for server and another copy for client for clarity)
1. On Server side:
   Start WinRM on your target server machine: e.g. DumyA
   This is Window based application, the output can be found both on screen and winrm.log
2. On Client Side (DumyB, can be any machine includes DumyA) in a command prompt:
a. To test the process of transaction commit, you may type:
   rmclient /s DumyA /t commit
b. To test the process of transaction abort, you may type:
   rmclient /s DumyA /t abort
  rmclient is DOS based application, and the output can be found both on screen and rmc.log

This tool has been tested against NT4, Window2000 and XP.

Contact:
You may send the output files to dtcsig alias for analysis.

Architecture:
Server:WinRM.exe handles user requests and traces the lifetime of  transaction on server side
Client:rmclient.exe talks to WinRM via RPC, and traces the lifetime of transaction on client side

Reference:
Platform SDK documentation
  Component Services
    COM+ Tool Developer�s Guide
       Tool Developer�s Concept
          Microsoft Distributed Transaction Coordinate
                 Life of a transaction
