Windows Server: File Replication Service Management Pack
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Version: 1.00c - December 2002

Status:  Released


Contents:
~~~~~~~~~

SONAR.EXE: 				Version 1.00 Build 1.0.1103.30687.  Refer to "Troubleshooting FRS.DOC" 
					for important running instructions. 

"Troubleshooting FRS.DOC"		Version 1.00c. 

TOPCHK.CMD, CONNSTAT.CMD, IOLOGSUM.CMD	Versions taken from Windows Server 2003 RC1.


SONAR Release notes:
~~~~~~~~~~~~~~~~~~~~

Perf Counters	The FRS Service is known to fail to respond to remote perfcounters in 
		Windows .NET Server builds up to 3675. If you experience this issue 
		with SONAR, please upgrade your Windows .NET 2003 systems 
		to build 3676 or later and retry. 

.NET CLR	Sonar uses the .NET Common Language Runtime. It is recommended that the
		it be used with the latest version of the .NET Framework / CLR 		(http://msdn.microsoft.com/netframework/downloads/updates/sp/download.asp) 

Terminal Server	Due to an issue in the CLR, SONAR can�t be used through Windows 
		Server 2003 RC1 terminal server.  The issue will be fixed in a future 
		version of WinForms. 
 
1010 Error 	The Performance Counters are sometimes known to get corrupted causing a 1010 event log error stating
		Event Log Errors stating the FileReplicaConn and FileReplicasets encounter an exception error and have been disabled.
		The /rpc switch has been provided to reset the registry key HKLM\System\CurrentControlSet\Services\FileReplicaSet\Performance\Disable Performance Counters) from 1 to 0.
		When run with this switch Sonar will make this change when it first accesses a machine -- if this key gets set in the middle of a Sonar run you will need to restart Sonar with the command line flag to have it work. 
		The /npc switch has been provided to disable performance counters.
 

Support Policy:
~~~~~~~~~~~~~~~

The SOFTWARE supplied here is  not  supported under any Microsoft standard support program or service.  You
can, however, report issues and bugs by sending e-mail to frsmon@microsoft.com. Microsoft will, at its sole 
discretion, address issues and bugs reported in this manner, and responses are not guaranteed. 

The SOFTWARE  (including instructions for its use and all printed and online documentation)  is provided AS IS 
without warranty of any kind. Microsoft further disclaims all implied warranties including, without limitation, 
any implied warranties of merchantability or of fitness for a particular purpose.  The entire risk arising out 
of the use or performance of the SOFTWARE and documentation remains with you.

In no event shall Microsoft, its authors, or anyone else involved in the creation,  production, or delivery of 
the SOFTWARE be liable for any damages whatsoever (including, without limitation, damages for loss of business 
profits,  business interruption, loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the SOFTWARE or documentation, even if Microsoft has been advised of the possibility of
such damages.
