DISCLAIMER

This utility is designed to extract messages pertaining to the W97m_Melissa Word virus only. It must be used exactly as described below or you may experience the loss of some or all of your mail.


Overview:
The "W97m_Melissa" Word Virus is a VBA Word macro that exploits the macro capabilities of Microsoft Word.  Upon execution the attached document in the email message the macro's behavior is to query the default address book of the client and generate a list of addresses.  The macro then forwards an email message with the same attached document to the list of addresses. When a recipient opens the new attachment the above behavior is manifested again.  The effect on you mail system is exponential forwarding of the same message.  Educated users usually wary of viruses, open and execute because it's from a friend.

How to address this issue:
1. If your enterprise has not seen this virus and wants to avoid it, shut down the Internet Mail Connector and any other foreign connectors.

2. Send email to all users asking them not to open any message with subject line "Very Important Message from...".  More importantly, don't open the attachment included in the message.

3. Use ExMerge to clean messages with a subject line containing "Important Message From".  Please read the ExMerge document for requirments.  This version has been custom modified to delete these messages.  Here are some important points to be made:

a. Make sure to select the TWO STEP option.

b. Make sure to ExMerge messages between specified dates (i.e. 3/26/99 -  present).  Note: If you choose option to ExMerge ALL dates, the messages containing the virus will not be deleted.

c. Choose option to archive messages.  This is the default.

d. Messages will be moved to a .PST file by the mailboxes name (i.e. TestUser.PST).  These files contain all messages that were deleted.  Once you are sure ExMerge ran safely, you can delete these files.

e. The utility must be run against every server in the enterprise.  It can be run in multiple instances to speed processing, selecting blocks of users has been scripted for ease.

