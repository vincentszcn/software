Unzip the enclosed files into a single directory.
On Windows NT 4.0, copy the PSAPI.DLL in the NT40 sub-directory into the install directory also (this is only required on NT 4.0).

Greg

